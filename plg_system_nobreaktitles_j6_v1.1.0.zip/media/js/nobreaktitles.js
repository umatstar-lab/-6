(function () {
    'use strict';

    const options = (window.Joomla && Joomla.getOptions)
        ? Joomla.getOptions('plg_system_nobreaktitles', {})
        : {};

    function list(value) {
        return String(value || '')
            .split(/[\n,;]+/)
            .map(function (s) { return s.trim(); })
            .filter(Boolean);
    }

    function unique(values) {
        return Array.from(new Set(values));
    }

    function getWords() {
        let words = [];

        if (options.mode === 'uk') {
            words = list(options.uk);
        } else if (options.mode === 'ru') {
            words = list(options.ru);
        } else if (options.mode === 'en') {
            words = list(options.en);
        } else if (options.mode === 'all') {
            words = list(options.uk).concat(list(options.ru), list(options.en));
        } else {
            const lang = (document.documentElement.lang || '').toLowerCase();

            if (lang.indexOf('uk') === 0) {
                words = list(options.uk);
            } else if (lang.indexOf('ru') === 0) {
                words = list(options.ru);
            } else if (lang.indexOf('en') === 0) {
                words = list(options.en);
            } else {
                words = list(options.uk).concat(list(options.ru), list(options.en));
            }
        }

        return unique(words.concat(list(options.abbr)));
    }

    function escapeRegex(value) {
        return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    function buildPattern() {
        const words = getWords()
            .sort(function (a, b) { return b.length - a.length; })
            .map(escapeRegex);

        if (!words.length) {
            return null;
        }

        /*
         * A short word/abbreviation must be followed by a normal space,
         * NBSP, tab or line break and then a letter/number.
         */
        return new RegExp(
            '(?<![\\p{L}\\p{N}])(' +
            words.join('|') +
            ')(?:[\\u0020\\u00A0\\t\\r\\n]+)(?=[\\p{L}\\p{N}])',
            'giu'
        );
    }

    const headingSelector = 'h1, h2, h3, h4, h5, h6';

    function processTextNode(node, pattern) {
        const text = node.nodeValue;
        if (!text || !pattern) return;

        pattern.lastIndex = 0;
        const result = text.replace(pattern, '$1\u00A0');
        pattern.lastIndex = 0;

        if (result !== text) {
            node.nodeValue = result;
        }
    }

    function processHeading(heading, pattern) {
        const walker = document.createTreeWalker(
            heading,
            NodeFilter.SHOW_TEXT,
            {
                acceptNode: function (node) {
                    const parent = node.parentElement;
                    if (!parent) return NodeFilter.FILTER_REJECT;

                    const tag = parent.tagName.toLowerCase();

                    if (tag === 'script' || tag === 'style' || tag === 'textarea') {
                        return NodeFilter.FILTER_REJECT;
                    }

                    return NodeFilter.FILTER_ACCEPT;
                }
            }
        );

        const nodes = [];
        let node;

        while ((node = walker.nextNode())) {
            nodes.push(node);
        }

        nodes.forEach(function (n) {
            processTextNode(n, pattern);
        });
    }

    function process(root, pattern) {
        if (!root || !root.querySelectorAll || !pattern) return;

        if (root.matches && root.matches(headingSelector)) {
            processHeading(root, pattern);
        }

        root.querySelectorAll(headingSelector).forEach(function (heading) {
            processHeading(heading, pattern);
        });
    }

    function init() {
        const pattern = buildPattern();

        if (!pattern) return;

        process(document, pattern);

        if (!document.body) return;

        const observer = new MutationObserver(function (mutations) {
            mutations.forEach(function (mutation) {
                mutation.addedNodes.forEach(function (node) {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        process(node, pattern);
                    } else if (node.nodeType === Node.TEXT_NODE && node.parentElement) {
                        const heading = node.parentElement.closest(headingSelector);

                        if (heading) {
                            processHeading(heading, pattern);
                        }
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
