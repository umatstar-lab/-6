<?php
namespace Joomla\Plugin\System\NoBreakTitles\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Event\Application\BeforeCompileHeadEvent;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;

final class NoBreakTitles extends CMSPlugin implements SubscriberInterface
{
    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return [
            'onBeforeCompileHead' => 'onBeforeCompileHead',
        ];
    }

    public function onBeforeCompileHead(BeforeCompileHeadEvent $event): void
    {
        $app = $event->getApplication();

        if (!$app || !$app->isClient('site') || !$this->params->get('enabled', 1)) {
            return;
        }

        $document = $event->getDocument();

        if (!$document || $document->getType() !== 'html') {
            return;
        }

        $config = [
            'mode' => (string) $this->params->get('language_mode', 'auto'),
            'uk' => (string) $this->params->get('uk_words', ''),
            'ru' => (string) $this->params->get('ru_words', ''),
            'en' => (string) $this->params->get('en_words', ''),
            'abbr' => (string) $this->params->get('abbreviations', ''),
        ];

        $json = json_encode(
            $config,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
        );

        $document->addScriptOptions('plg_system_nobreaktitles', $config);

        $document->addScript(
            'media/plg_system_nobreaktitles/js/nobreaktitles.js',
            [],
            ['defer' => true]
        );
    }
}
